"""Package existing execution bytes; does not rerun or alter model outputs."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

REPO = Path(__file__).resolve().parents[1]
OUTPUT = REPO / "evidence/evaluation"
RUNS = {
    "attempt-01-default-cache": REPO / "tmp/final-evaluation-all-profiles",
    "attempt-02-default-cache": REPO / "tmp/final-evaluation-llm-retry",
    "attempt-03-bounded-cache": REPO / "tmp/final-evaluation-llm-bounded",
}
CORE = ("__init__", "models", "parsing", "_parse_child", "extraction", "local_model", "llm", "rules", "evaluation", "corpus")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    copies = []
    members = []
    derived = []

    def copy(source, relative):
        destination = OUTPUT / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        assert digest(source) == digest(destination)
        copies.append({"source": str(source.relative_to(REPO)), "destination": str(destination.relative_to(REPO)),
                       "sha256": digest(source), "bytes": source.stat().st_size, "byte_for_byte": True})

    summaries = {}
    for name, root in RUNS.items():
        summary_path = root / "evaluation/summary.json"
        summary = json.loads(summary_path.read_text())
        summaries[name] = summary
        # These views are explicitly derived from fields captured in the original
        # result. They do not assert a commit or provenance unavailable at runtime.
        if not (root / "source-at-execution.json").exists():
            write_json(root / "source-at-execution.json", summary["source"])
        derived.append({"artifact": str((root / "source-at-execution.json").relative_to(REPO)),
                        "source": str(summary_path.relative_to(REPO)), "json_pointer": "/source",
                        "operation": "Post-run view of the exact source identity object captured at evaluation start; original git claims preserved."})
        if not (root / "model-usage.json").exists():
            traces = [json.loads(p.read_text()) for p in (root / "model-traces").glob("*.json")]
            usage = {key: sum(trace["response"].get("usage", {}).get(key, 0) for trace in traces)
                     for key in ("prompt_tokens", "completion_tokens", "total_tokens")}
            write_json(root / "model-usage.json", {"successful_response_count": len(traces), "usage": usage,
                                                  "external_api_cost_usd": 0, "compute_cost_usd": None,
                                                  "scope": "Usage of completed responses only; interrupted requests may have unreported tokens."})
        derived.append({"artifact": str((root / "model-usage.json").relative_to(REPO)),
                        "source": str((root / "model-traces").relative_to(REPO)),
                        "operation": "Sum reported completed-response usage; interrupted requests can have unreported tokens."})
        for original, relative in ((summary_path, "summary.json"),
                                   (root / "harness.json", "harness.json"),
                                   (root / "source-at-execution.json", "source-at-execution.json"),
                                   (root / "evaluation/policy-before-run.json", "policy-before-run.json"),
                                   (root / "model-usage.json", "model-usage.json"),
                                   (root / "server.log", "server.log")):
            copy(original, Path(name) / relative)
        if (root / "server-resource-timeline.jsonl").exists():
            copy(root / "server-resource-timeline.jsonl", Path(name) / "server-resource-timeline.jsonl")
        for directory in ("evaluation/documents", "evaluation/parsed", "model-traces"):
            for path in sorted((root / directory).rglob("*")):
                if path.is_file() and not path.is_symlink():
                    relative = Path("runs") / name / path.relative_to(root)
                    members.append((path, relative.as_posix()))

    corpus_root = REPO / "tmp/final-corpus-seed42"
    manifest_path = corpus_root / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    copy(manifest_path, Path("dataset-manifest.json"))
    copy(REPO / "tmp/final-linear-training.json", Path("local-linear-training.json"))
    copy(REPO / "tmp/final-linear-model.json", Path("local-linear-model.json"))
    copy(REPO / "tmp/llm-repeatability-two-original-attempts.json", Path("repeatability-two-original-attempts.json"))
    development_files = {
        "tmp/parser-corpus/manifest.json": "dataset-manifest.json",
        "tmp/extraction-model-v2.json": "local-linear-model-format-1.0.json",
        "tmp/extraction-training-v2.json": "training-report-v2.json",
        "tmp/extraction-tune.json": "classification-before-heading-features.json",
        "tmp/extraction-tune-v2.json": "classification-after-heading-features.json",
    }
    for source, name in development_files.items():
        copy(REPO / source, Path("development-tuning") / name)
    earlier_model = json.loads((REPO / "tmp/extraction-model-v2.json").read_text())
    earlier_manifest = json.loads((REPO / "tmp/parser-corpus/manifest.json").read_text())
    earlier_inputs = {entry["path"]: entry["sha256"] for entry in earlier_manifest["documents"]}
    if any(earlier_inputs[entry["path"]] != entry["sha256"] for entry in earlier_model["metadata"]["training_inputs"]):
        raise RuntimeError("Development training inputs differ from their original manifest")
    before = json.loads((REPO / "tmp/extraction-tune.json").read_text())
    after = json.loads((REPO / "tmp/extraction-tune-v2.json").read_text())
    tuning_provenance = {
        "stage": "pre-final development; distinct from the final model fitted on 72 documents",
        "saved_model_format": earlier_model["format"], "model_sha256": digest(REPO / "tmp/extraction-model-v2.json"),
        "manifest_sha256": digest(REPO / "tmp/parser-corpus/manifest.json"),
        "training_documents": len(earlier_model["metadata"]["training_inputs"]),
        "thresholds": earlier_model["thresholds"], "classification_report_only": True,
        "before": {"documents": len(before), "correct": sum(row["kind"] == row["expected_kind"] for row in before), "unknown": sum(row["kind"] == "unknown" for row in before)},
        "after": {"documents": len(after), "correct": sum(row["kind"] == row["expected"] for row in after), "unknown": sum(row["kind"] == "unknown" for row in after)},
        "scope": "The development change emphasized the document heading. Thresholds were not lowered. These reports are not final field-quality metrics and do not evaluate the later format 1.1 artifact fitted on 72 documents.",
    }
    write_json(OUTPUT / "development-tuning/provenance.json", tuning_provenance)
    derived.append({"artifact": "evidence/evaluation/development-tuning/provenance.json", "sources": list(development_files), "operation": "count original tuning classifications and verify training input hashes"})
    for item in manifest["documents"]:
        if item["split"] != "test":
            continue
        original = corpus_root / item["path"]
        if digest(original) != item["sha256"]:
            raise RuntimeError(f"Input differs from frozen manifest: {original}")
        members.append((original, str(Path("inputs") / item["path"])))

    source_records = []
    for module in CORE:
        repository_path = f"src/dci/{module}.py"
        original = OUTPUT / "source-snapshot" / repository_path
        expected = summaries["attempt-03-bounded-cache"]["source"]["source_files"][repository_path]
        if digest(original) != expected:
            raise RuntimeError(f"Original source snapshot mismatch: {repository_path}")
        for summary in summaries.values():
            if summary["source"]["source_files"][repository_path] != expected:
                raise RuntimeError(f"Cross-run original source mismatch: {repository_path}")
        source_records.append({"repository_path": repository_path, "snapshot_path": str(original.relative_to(REPO)),
                               "sha256": expected, "current_repository_matches": digest(REPO / repository_path) == expected})
        members.append((original, f"source-snapshot/{repository_path}"))
    copy(REPO / "scripts/run_llm_evaluation.py", Path("source-snapshot/scripts/run_llm_evaluation.py"))
    launcher = OUTPUT / "source-snapshot/scripts/run_llm_evaluation.py"
    expected_launcher = json.loads((RUNS["attempt-03-bounded-cache"] / "harness.json").read_text())["harness_sha256"]
    if digest(launcher) != expected_launcher:
        raise RuntimeError("Bounded launcher differs from execution hash")
    members.append((launcher, "source-snapshot/scripts/run_llm_evaluation.py"))
    write_json(OUTPUT / "source-snapshot/component-provenance.json", source_records)
    for path in (OUTPUT / "source-snapshot/index.json", OUTPUT / "source-snapshot/component-provenance.json"):
        members.append((path, f"source-snapshot/{path.name}"))

    trace_path = next((RUNS["attempt-03-bounded-cache"] / "model-traces").glob("*.json"))
    trace = json.loads(trace_path.read_text())
    prompt = trace["request"]["messages"][0]["content"].encode("utf-8")
    if hashlib.sha256(prompt).hexdigest() != trace["telemetry"]["prompt_sha256"]:
        raise RuntimeError("Prompt differs from recorded prompt digest")
    prompt_path = OUTPUT / "prompt-structured-extraction-1.2.txt"
    prompt_path.write_bytes(prompt)
    derived.append({"artifact": str(prompt_path.relative_to(REPO)), "source": str(trace_path.relative_to(REPO)),
                    "json_pointer": "/request/messages/0/content", "sha256": digest(prompt_path)})
    members.append((prompt_path, "source-snapshot/prompt-structured-extraction-1.2.txt"))

    initial = summaries["attempt-01-default-cache"]
    bounded = summaries["attempt-03-bounded-cache"]
    manifest_hashes = {summary["manifest_sha256"] for summary in summaries.values()}
    if manifest_hashes != {digest(manifest_path)}:
        raise RuntimeError("Evaluation datasets differ")
    comparison = {
        "schema_version": "1.0", "kind": "derived_three_profile_comparison",
        "derivation": "Baseline and local-linear metrics are copied from attempt01. Local-LLM metrics are copied from the complete bounded operational run attempt03. Original summaries are preserved byte-for-byte beside this view.",
        "manifest_sha256": digest(manifest_path), "test_documents": 36,
        "model_training_documents": 72, "model_training_fields": 576,
        "model_or_prompt_tuning_after_final_started": False,
        "resource_profile_change": "Disable runtime cache/checkpoints and reduce batching after two process deaths. Same model, prompt, seed, context, threads, dataset and thresholds. This was an operational correction, not accuracy tuning.",
        "profiles": {"baseline": initial["profiles"]["baseline"], "local-linear": initial["profiles"]["local-linear"], "local-llm": bounded["profiles"]["local-llm"]},
        "source_metric_selection": {"baseline": "attempt-01-default-cache/summary.json#/profiles/baseline",
                                    "local-linear": "attempt-01-default-cache/summary.json#/profiles/local-linear",
                                    "local-llm": "attempt-03-bounded-cache/summary.json#/profiles/local-llm"},
        "reliability_incidents": [
            {"attempt": "attempt-01-default-cache", "successful_responses": 12, "unavailable_attempts": 24, "server_exit": -9, "cause": "Unexplained SIGKILL; no kernel or cgroup cause evidence available."},
            {"attempt": "attempt-02-default-cache", "successful_responses": 19, "unavailable_attempts": 17, "server_exit": -9, "observed_peak_rss_kib": 3635604, "cause": "Unexplained SIGKILL with observed memory growth; not a controlled stop and not a proved OOM."},
        ],
        "interpretation": ["Eligibility is before mandatory human approval, not automatic publication.",
                           "The local-linear profile meets the predeclared synthetic benchmark gate; no real-supplier generalization is asserted.",
                           "The bounded Qwen profile executed all 36 inputs but fails the quality/coverage gate and remains experimental.",
                           "Zero false eligibility with zero eligible documents is not evidence of accepted-document quality; that ratio is null.",
                           "Resource and latency measurements were made in a shared isolated execution environment."],
        "provenance": {"component_snapshot": "source-snapshot/component-provenance.json", "original_git_claims_preserved": True,
                       "note": "Original git_commit/dirty values are retained. Later audited-human-classification rules/store/API changes are not claimed as original benchmark sources."},
    }
    # Counts are read back from the original reports, avoiding handwritten totals.
    comparison["test_documents"] = bounded["dataset"]["evaluated_test_documents"]
    training = json.loads((OUTPUT / "local-linear-training.json").read_text())
    comparison["model_training_documents"] = training["training_documents"]
    comparison["model_training_fields"] = training["training_fields"]
    for incident in comparison["reliability_incidents"]:
        name = incident["attempt"]
        incident["successful_responses"] = json.loads((OUTPUT / name / "model-usage.json").read_text())["successful_response_count"]
        incident["unavailable_attempts"] = summaries[name]["profiles"]["local-llm"]["failures"]
        harness = json.loads((OUTPUT / name / "harness.json").read_text())
        incident["server_exit"] = harness["server_exit_code"]
        if "observed_peak_rss_kib" in incident:
            incident["observed_peak_rss_kib"] = harness["observed_server_peak_rss_kib"]
    write_json(OUTPUT / "summary.json", comparison)
    derived.append({"artifact": "evidence/evaluation/summary.json", "sources": [str((root / "evaluation/summary.json").relative_to(REPO)) for root in RUNS.values()], "operation": "explicit profile selection and incident summary; no output values changed"})

    archive_path = OUTPUT / "raw-executions.tar.gz"
    archive_members = []
    members.append((Path(__file__), "reproduction/package_evaluation_evidence.py"))
    with archive_path.open("wb") as file, gzip.GzipFile(filename="", mode="wb", fileobj=file, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(mode="w", fileobj=compressed) as archive:
            for original, member in sorted(members, key=lambda entry: entry[1]):
                data = original.read_bytes()
                info = tarfile.TarInfo(member)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
                archive_members.append({"source": str(original.relative_to(REPO)), "member": member,
                                        "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "byte_for_byte": True})
    # Re-open every archive entry and compare its bytes, rather than only trusting
    # successful compression or a whole-archive digest.
    with tarfile.open(archive_path, "r:gz") as archive:
        indexed = {entry["member"]: entry for entry in archive_members}
        for member in archive.getmembers():
            if not member.isfile() or member.name not in indexed:
                raise RuntimeError("Unexpected archive entry")
            content = archive.extractfile(member).read()
            if hashlib.sha256(content).hexdigest() != indexed[member.name]["sha256"]:
                raise RuntimeError("Archive member differs from original")
    inventory = {
        "schema_version": "1.0", "purpose": "Original synthetic evaluation evidence and explicit derived views; content hashes establish correspondence, not certification.",
        "original_run_paths": {name: str(path.relative_to(REPO)) for name, path in RUNS.items()},
        "original_artifact_copies": copies,
        "derived_views": derived,
        "original_core_component_snapshots": source_records,
        "archive": {"path": str(archive_path.relative_to(REPO)), "sha256": digest(archive_path), "bytes": archive_path.stat().st_size,
                    "member_count": len(archive_members), "uncompressed_bytes": sum(entry["bytes"] for entry in archive_members),
                    "members": archive_members, "verification": "Every archived member was reopened and its digest compared with the original bytes."},
        "exclusions": ["GGUF weights and runtime binaries", "parser checkpoints (duplicated page payloads)", "training/tuning PDF copies (reproducible from generator and their respective manifests)", "application actor tokens and databases", "unrelated temporary work"],
        "safety_review": "Inputs contain synthetic procurement identities and inert attacker.invalid text. No customer documents, personal identifiers, API tokens or account credentials were selected.",
    }
    inventory["direct_file_manifest"] = [{"path": str(path.relative_to(REPO)), "sha256": digest(path), "bytes": path.stat().st_size}
                                         for path in sorted(OUTPUT.rglob("*")) if path.is_file() and path != OUTPUT / "index.json"]
    write_json(OUTPUT / "index.json", inventory)
    print(json.dumps({"files": sum(p.is_file() for p in OUTPUT.rglob("*")), "original_copies": len(copies), "archive_members": len(archive_members),
                      "archive_bytes": archive_path.stat().st_size, "total_bytes": sum(p.stat().st_size for p in OUTPUT.rglob("*") if p.is_file()),
                      "archive_sha256": digest(archive_path)}, indent=2))


if __name__ == "__main__":
    main()
